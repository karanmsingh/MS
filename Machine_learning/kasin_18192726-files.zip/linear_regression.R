
#Reading Data
df <- read.csv("C://Users//Karan//Desktop//MSc_DataAnalytics//Sem 1//Projects//Machine_learning//[2]//PRSA_Data_20130301-20170228//PRSA_Data_Aotizhongxin_20130301-20170228.csv")
head(df)
colnames(df)

# Data Cleaning
summary(df)
df[is.na(df)] <- 0
summary(df)

# Data Selection
df2 <- data.frame(df$PM2.5, df$NO2)


#Making sure the data is clean
summary(df2)

plot(df2)


#Splitting the data 
set.seed(123)
library(caTools)
split <- sample.split(df2$df.PM2.5, SplitRatio = 2/3)
split

train <- subset(df2, split ="TRUE")
test <- subset(df2, split = "FALSE")
train

#creating the model
Model <- lm(formula = df.PM2.5 ~ df.NO2, data = train )
summary(Model)

#Prediction
pred <- predict(Model, test)
pred


#Plotting to compare predicted and actual values
#install.packages("ggplot2")
library(ggplot2)
ggplot() + geom_point(aes(x = train$df.NO2, y = train$df.PM2.5),
                      color = 'red') +
  geom_line(aes(x = train$df.NO2, y = predict(Model, train)),
                color = 'blue')+ 
  ggtitle('PM 2.5 and NO2 (training set)')+
  xlab('Concentration of NO2')+ ylab('Concentration of PM 2.5')


#Plotting Test set 
ggplot() + geom_point(aes(x = test$df.NO2, y = test$df.PM2.5),
                      color = 'red') +
  geom_line(aes(x = train$df.NO2, y = predict(Model, train)),
            color = 'blue')+ 
  ggtitle('PM 2.5 and NO2 (test set)')+
  xlab('Concentration of NO2')+ ylab('Concentration of PM 2.5')


#Finding Accuracy
rmse = sqrt(mean(pred - df2$df.PM2.5)^2)
rmse

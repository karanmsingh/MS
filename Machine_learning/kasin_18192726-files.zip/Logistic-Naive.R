
#Read data
df <- read.csv("C://Users//Karan//Desktop//MSc_DataAnalytics//Sem 1//Projects//Machine_learning//[3]//googleplaystore.csv")
colnames(df)

#####Data Cleaning
df[is.na(df)] <- 0
#Removing NaN and 0 from App Types
df<-df[!(df$Type =="NaN"),]
df<-df[!(df$Type =="0"),]


#####Data Selection
inst <- data.frame(df$Installs, df$Type)
summary(inst)



#####Data Transformation

#Converting the Type Column to Binary
inst$df.Type <- as.character(inst$df.Type )
inst$df.Type <- replace(inst$df.Type, inst$df.Type == 'Free', '1')
inst$df.Type <- replace(inst$df.Type, inst$df.Type == 'Paid', '0')
inst$df.Type <- factor(inst$df.Type)



summary(inst)
head(inst)

#Removing + and , from Installs
library(stringr)
inst$df.Installs <- str_remove_all(inst$df.Installs , "[+]")
inst$df.Installs <- str_remove_all(inst$df.Installs , "[,]")
head(inst)

#converting to numeric
inst$df.Installs <- as.integer(inst$df.Installs)


summary(inst)


######Logistic 
table(inst$df.Type)

#Sampling
library(caret)
'%ni%' <- Negate('%in%')  # define 'not in' func
options(scipen=999)  # prevents printing scientific notation

#Training and Test data 
set.seed(100)
trainDataIndex <- createDataPartition(inst$df.Type , p=0.7, list = F)  # 70% training data
trainData <- inst[trainDataIndex, ]
testData <- inst[-trainDataIndex, ]

table(trainData$df.Type)

#Need to downsample "Free" apps
set.seed(100)
down_train <- downSample(x = trainData[, colnames(trainData) %ni% "Type"],
                         y = trainData$df.Type)

summary(down_train)

table(down_train$df.Type)


## Up Sample
set.seed(100)
up_train <- upSample(x = trainData[, colnames(trainData) %ni% "Type"],
                     y = trainData$df.Type)
table(up_train$df.Type)
up_train <- up_train[,-1]
summary(up_train)


# Build Logistic Model
logitmod <- glm(df.Type ~ df.Installs, family = "binomial", data=down_train)
summary(logitmod)


pred <- predict(logitmod, newdata = testData, type = "response")

y_pred_num <- ifelse(pred > 0.5, 1, 0)
y_pred <- factor(y_pred_num, levels=c(0, 1))
y_act <- testData$df.Type
mean(y_pred == y_act)
library(e1071)
library(caret)

(table(Actualvalue = testData$df.Type, Predictedvalue = pred>0.5))
########################################################################






##################################################################################
######Naive Bayes

set.seed(2)
id <- sample(2, nrow(inst), prob = c(0.7,0.3), replace = T)
inst_train <- inst[id == 1,]
inst_test <- inst[id==2, ]
library(e1071)
library(caret)


instb <- naiveBayes(df.Type ~., data = inst)
instb

#Evaluation
pred <- predict(instb, inst_test)
confusionMatrix(table(pred,inst_test$df.Type))

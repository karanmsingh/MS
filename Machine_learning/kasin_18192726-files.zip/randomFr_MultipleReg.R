slides <- read.csv("C:/Users/Karan/Desktop/MSc_DataAnalytics/Sem 1/Projects/Machine_learning/[1]/Global_Landslide_Catalog_Export.csv")
head(slides)


######Data Cleaning 
#Converting "exact" and "unknown" to 0
slides$location_accuracy <- as.character(slides$location_accuracy )
slides$location_accuracy <- replace(slides$location_accuracy, slides$location_accuracy == 'exact', NA)
head(slides)
slides$location_accuracy <- replace(slides$location_accuracy, slides$location_accuracy == 'unknown', NA)
head(slides)
slides$location_accuracy[which(is.na(slides$location_accuracy))] <- '0'
slides
library(stringr)

####Adding a numeric column for landslide size
slides$Landslide_size = as.character(slides$landslide_size)
slides$Landslide_size <- as.numeric(as.factor(slides$Landslide_size))
head(slides)

#removing "km" from column
slides$location_accuracy <- str_remove_all(slides$location_accuracy, "[km]")
head(slides)

######removing records with Blank landslide size
slides <- slides[!(slides$landslide_size =="1"),]

###Changing Unknown Landlside size to Small
slides$Landslide_size[df$slides$Landslide_size == "6"] <- "5" 

##Dropping Landslide size textual data
slides$landslide_size <- NULL 
head(slides)

#Converting to character
slides$fatality_count <- as.character(slides$fatality_count)

colnames(slides)


#######Data Selection

slides$fatality_count[slides$fatality_count == ""] <- 0

df = df <- data.frame(
  slides$location_accuracy,
  slides$Landslide_size,
  slides$fatality_count
)
head(df)



#####Data Transformation
df$slides.fatality_count <- as.integer(df$slides.fatality_count)
df$slides.fatality_count[is.na(df$slides.fatality_count)] <- 0
str(df)

#removing null and confirming the integrity of data
df <- df[!is.na(df$slides.fatality_count), ]
df[!complete.cases(df),]
df

#Converting to integer
df$slides.location_accuracy <- as.integer(df$slides.location_accuracy)
df <- df[!is.na(df$slides.location_accuracy), ]
df$slides.Landslide_size <- as.integer(df$slides.Landslide_size)

plot(df)

#####################################################
###############Random forest 
library(ggplot2)
library(cowplot)
library(randomForest)
summary(df)

#Splitting the data
set.seed(2)
id <- sample(2, nrow(df), prob = c(0.7,0.3), replace = TRUE)

train <- df[id ==1,]
test <- df[id==2,]

head(df)
summary(df)


library(randomForest)


bestmtry <- tuneRF(train, train$slides.fatality_count, stepFactor = 1.2, improve = 0.01, trace = T, plot = T)

land_slides_forest <- randomForest(slides.fatality_count ~., data = df )
land_slides_forest

p1 = predict(land_slides, data.frame(Level = 6.5))

importance(land_slides_forest)

varImpPlot(land_slides_forest)
plot(land_slides_forest)

##########################










############################################################
#####################multiple regression



set.seed(2)
library(caTools)
split <- sample.split(df, SplitRatio = 0.7)
split
train <- subset(df, split ="TRUE")
test <- subset(df, split = "FALSE")
train

#create the model
Model <- lm(slides.fatality_count ~., data =train )
summary(Model)

#Prediction
pred <- predict(Model, test)
pred


#Comparing predicted and actual values
plot(test$slides.fatality_count, type="l", lty = 1.8, col= "blue")
lines(pred, type = "l", col = "red")

plot(pred, type="l", lty = 1.8, col="red")

#Finding Accuracy
rmse = sqrt(mean(pred - df$slides.fatality_count)^2)
rmse

